<?php
/**
 * Plugin Name: Genius Assistants
 * Description: ИИ-ассистенты Genius: телеграм-боты и веб-версии. Вход и баланс — общие с kie-tts-wp (тот же аккаунт пользователя). Админка токенов ботов, галерея, чат-виджет.
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 8.0
 * Author: Genius-bot
 */
if (!defined('ABSPATH')) { exit; }

// Модуль опирается на учётные записи и баланс kie-tts-wp. Грузим его bootstrap.
require_once __DIR__ . '/bootstrap.php';
